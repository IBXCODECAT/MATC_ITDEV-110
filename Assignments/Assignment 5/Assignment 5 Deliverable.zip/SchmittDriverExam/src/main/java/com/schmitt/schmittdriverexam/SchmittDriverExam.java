package com.schmitt.schmittdriverexam;

import javax.sound.sampled.LineUnavailableException;

public class SchmittDriverExam {

    public static void main(String[] args) throws LineUnavailableException {
        new Admin().MissionControl();
    }
}
