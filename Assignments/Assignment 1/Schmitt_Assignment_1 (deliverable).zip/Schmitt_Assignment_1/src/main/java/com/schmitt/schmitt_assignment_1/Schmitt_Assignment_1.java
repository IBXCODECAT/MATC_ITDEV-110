/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.schmitt.schmitt_assignment_1;

/**
 * @CourseNumber ITDEV 110-004
 * @AssignmentNumber 1
 * @author Nathan Schmitt
 */
public class Schmitt_Assignment_1
{
    public static void main(String[] args)
    {
        AboutMe meObj = new AboutMe();
    }
}
