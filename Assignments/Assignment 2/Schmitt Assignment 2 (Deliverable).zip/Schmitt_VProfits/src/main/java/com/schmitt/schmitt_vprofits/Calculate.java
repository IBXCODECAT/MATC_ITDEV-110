package com.schmitt.schmitt_vprofits;

/**
 * @author Nathan Schmitt
 */
public class Calculate {
    
    //In the assignment it was stated that we needed at least three classes
    //This is my third class I guess
    
    protected double CalculateProfits(double price, double percentage)
    {
        return price * percentage;
    }
}
