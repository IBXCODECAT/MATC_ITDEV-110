package com.schmitt.schmitt_vprofits;

import java.util.Scanner;

/**
 * @CourseNumber ITDEV-110-004
 * @Assignment Assignment 2
 * @author Nathan schmitt
 */
public class Schmitt_VProfits {

    public static void main(String[] args) {
        Admin adminObj = new Admin();
        
        adminObj.Intro();
        adminObj.Start();
        
        
    }
}
