package com.schmitt.schmittfinalexam;

/**
 * @Assignment FINAL EXAM
 * @CourseNumber ITDEV-110-004
 * @author Nathan Schmitt
 */
public class SchmittFinalExam {

    public static void main(String[] args) 
    {
        Controller.Execute();
    }
}
