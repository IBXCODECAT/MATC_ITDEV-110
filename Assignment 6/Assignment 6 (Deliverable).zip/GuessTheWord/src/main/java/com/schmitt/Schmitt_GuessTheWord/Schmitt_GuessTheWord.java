package com.schmitt.Schmitt_GuessTheWord;

/**
 * @author Nathan Schmitt
 */
public class Schmitt_GuessTheWord 
{
    public static void main(String[] args)
    {
        Controller.Execute();
    }
}
